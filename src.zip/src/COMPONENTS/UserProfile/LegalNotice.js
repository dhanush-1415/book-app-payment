import React from 'react'
import './LegalNotice.css'

const LegalNotice = () => {
    return (
        <div className='legalnotice'>
            <h1 className='mainhead2'>Legal Notice</h1>
            <div className='legalnoticein'>
                <div className='pg'>
                    <h2>Purpose</h2>
                    <p>The following outlines the terms of use for all BoroBazar template, services and website. Before you sign up and download or use RedQ downloadable product for your own purposes, please make sure you have read, understood, and agreed to all the terms.By using RedQ and/or other products, we assume you've accepted the terms of use given below.</p>
                </div>
                <div className='pg'>
                    <h2>Purpose</h2>
                    <p>The following outlines the terms of use for all BoroBazar template, services and website. Before you sign up and download or use RedQ downloadable product for your own purposes, please make sure you have read, understood, and agreed to all the terms.By using RedQ and/or other products, we assume you've accepted the terms of use given below.</p>
                </div>
                <div className='pg'>
                    <h2>Purpose</h2>
                    <p>The following outlines the terms of use for all BoroBazar template, services and website. Before you sign up and download or use RedQ downloadable product for your own purposes, please make sure you have read, understood, and agreed to all the terms.By using RedQ and/or other products, we assume you've accepted the terms of use given below.</p>
                </div>
                <div className='pg'>
                    <h2>Purpose</h2>
                    <p>The following outlines the terms of use for all BoroBazar template, services and website. Before you sign up and download or use RedQ downloadable product for your own purposes, please make sure you have read, understood, and agreed to all the terms.By using RedQ and/or other products, we assume you've accepted the terms of use given below.</p>
                </div>
                <div className='pg'>
                    <h2>Purpose</h2>
                    <p>The following outlines the terms of use for all BoroBazar template, services and website. Before you sign up and download or use RedQ downloadable product for your own purposes, please make sure you have read, understood, and agreed to all the terms.By using RedQ and/or other products, we assume you've accepted the terms of use given below.</p>
                </div>
                <div className='pg'>
                    <h2>Purpose</h2>
                    <p>The following outlines the terms of use for all BoroBazar template, services and website. Before you sign up and download or use RedQ downloadable product for your own purposes, please make sure you have read, understood, and agreed to all the terms.By using RedQ and/or other products, we assume you've accepted the terms of use given below.</p>
                </div>
            </div>
        </div>
    )
}

export default LegalNotice