import { atom } from "recoil";

export const updateAddressProvider = atom({
    key: "updateAddressProvider",
    default: false,
});