import { atom } from "recoil";

export const newAddressProvider = atom({
    key: "newAddressProvider",
    default: false,
});