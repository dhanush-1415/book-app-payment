import { atom } from "recoil";

export const productPopupIdProvider = atom({
    key: "productPopupIdProvider",
    default: '',
});