import { atom } from "recoil";

export const productPopupProvider = atom({
    key: "productPopupProvider",
    default: false,
});