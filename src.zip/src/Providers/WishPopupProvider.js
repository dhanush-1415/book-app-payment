import { atom } from "recoil";

export const wishPopupState = atom({
    key: "wishPopupState",
    default: false,
});