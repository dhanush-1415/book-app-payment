import { atom } from "recoil";

export const cartReloadState = atom({
    key: "cartReloadState",
    default: false,
});