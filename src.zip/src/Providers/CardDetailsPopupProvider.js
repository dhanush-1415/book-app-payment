import { atom } from "recoil";

export const cardDetailsPopupState = atom({
    key: "cardDetailsPopupState",
    default: true,
});