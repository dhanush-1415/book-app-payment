import { atom } from "recoil";

export const cartPopupState = atom({
    key: "cartPopupState",
    default: false,
});